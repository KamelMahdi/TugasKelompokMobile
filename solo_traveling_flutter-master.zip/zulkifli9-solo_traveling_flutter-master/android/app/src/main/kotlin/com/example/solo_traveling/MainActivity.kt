package com.example.solo_traveling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
